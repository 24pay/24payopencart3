<?php
$_['text_title']      = '24-pay';
$_['token_error']     = 'Error to create a payment token. Contact the store owner';
$_['text_order']      = 'Order #';
$_['button_confirm']  = 'Pay with 24-pay';
?>
