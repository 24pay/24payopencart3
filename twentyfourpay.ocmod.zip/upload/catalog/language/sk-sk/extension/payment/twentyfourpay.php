<?php
$_['text_title']  = '24-pay (platobná brána)';
$_['token_error'] = 'Nepodarilo sa vytvoriť token na platbu. Kontaktujte majiteľa eshopu';
$_['text_order']  = 'Objednávka #';
$_['button_confirm']  = 'Zaplatiť cez 24-pay';
?>
